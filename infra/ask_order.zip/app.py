# app.py
import json
import boto3
import os

dynamodb = boto3.client("dynamodb")
ORDERS_TABLE = os.environ["ORDERS_TABLE"]

def handler(event, context):
    body = json.loads(event.get("body", "{}"))

    order_id = body.get("orderId")
    question = body.get("question", "")

    if not order_id:
        return {"statusCode": 400, "body": "orderId is required"}

    # Fetch order from DynamoDB
    resp = dynamodb.get_item(
        TableName=ORDERS_TABLE,
        Key={"orderId": {"S": order_id}}
    )

    order = resp.get("Item")
    if not order:
        return {"statusCode": 404, "body": "Order not found"}

    # Call LLM provider (not implemented yet)
    answer = f"Your order {order_id} is in status: {order['status']['S']}"

    return {
        "statusCode": 200,
        "body": json.dumps({"answer": answer})
    }

